#include <windows.h>
#include <iostream>

int main() {
    HKEY hKey;
    LONG lRes = RegOpenKeyEx(HKEY_LOCAL_MACHINE, "SOFTWARE\\Pertinax\\SecurityTool", 0, KEY_READ, &hKey);
    if (lRes == ERROR_SUCCESS) {
        std::cout << "LandesErlaubnis bestätigt. Tool wird gestartet...\n";
        system("start PertinaxCoreService.exe");
    } else {
        MessageBox(NULL, "Keine gültige Landeserlaubnis erkannt. Bitte Setup prüfen.", "Start verweigert", MB_ICONERROR);
        return 1;
    }
    return 0;
}
