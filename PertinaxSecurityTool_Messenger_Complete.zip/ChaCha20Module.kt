
package com.pertinax.security.messenger

import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.spec.ChaCha20ParameterSpec
import javax.crypto.spec.SecretKeySpec

object ChaCha20Module {
    private const val NONCE_LENGTH = 12
    private const val ALGORITHM = "ChaCha20-Poly1305"

    fun encrypt(plain: ByteArray): ByteArray {
        val keyBytes = getKey()
        val key: SecretKey = SecretKeySpec(keyBytes, "ChaCha20")
        val nonce = generateNonce()

        val cipher = Cipher.getInstance(ALGORITHM)
        val spec = ChaCha20ParameterSpec(nonce, 0)
        cipher.init(Cipher.ENCRYPT_MODE, key, spec)

        val ciphertext = cipher.doFinal(plain)
        return nonce + ciphertext
    }

    fun decrypt(cipherText: ByteArray): ByteArray? {
        val keyBytes = getKey()
        val key: SecretKey = SecretKeySpec(keyBytes, "ChaCha20")
        val nonce = cipherText.copyOfRange(0, NONCE_LENGTH)
        val cipherData = cipherText.copyOfRange(NONCE_LENGTH, cipherText.size)

        val cipher = Cipher.getInstance(ALGORITHM)
        val spec = ChaCha20ParameterSpec(nonce, 0)
        cipher.init(Cipher.DECRYPT_MODE, key, spec)

        return cipher.doFinal(cipherData)
    }

    private fun getKey(): ByteArray {
        return ByteArray(32) { 0x1A.toByte() }
    }

    private fun generateNonce(): ByteArray {
        return ByteArray(NONCE_LENGTH) { it.toByte() }
    }
}
