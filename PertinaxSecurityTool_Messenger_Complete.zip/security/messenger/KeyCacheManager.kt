package com.pertinax.security.messenger

import java.util.concurrent.ConcurrentHashMap

object KeyCacheManager {
    private val sessionKeys = ConcurrentHashMap<String, ByteArray>()

    fun storeSessionKey(sessionId: String, key: ByteArray) {
        sessionKeys[sessionId] = key
    }

    fun getSessionKey(sessionId: String): ByteArray? {
        return sessionKeys[sessionId]
    }

    fun rotateSessionKey(sessionId: String) {
        val newKey = ByteArray(32) { it.toByte() } // Dummy-Key – real ersetzen
        storeSessionKey(sessionId, newKey)
    }

    fun clearSession(sessionId: String) {
        sessionKeys.remove(sessionId)
    }
}
