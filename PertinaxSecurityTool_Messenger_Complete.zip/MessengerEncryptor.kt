
package com.pertinax.security.messenger

import android.util.Base64

object MessengerEncryptor {

    fun sendMessage(plainText: String): String {
        val encrypted = ChaCha20Module.encrypt(plainText.toByteArray())
        return Base64.encodeToString(encrypted, Base64.NO_WRAP)
    }

    fun receiveMessage(base64: String): String {
        return try {
            val cipher = Base64.decode(base64, Base64.NO_WRAP)
            val decrypted = ChaCha20Module.decrypt(cipher)
            decrypted?.decodeToString() ?: "Fehler bei Entschlüsselung"
        } catch (e: Exception) {
            "Fehler: ${e.message}"
        }
    }
}
