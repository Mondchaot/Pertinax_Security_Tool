package com.pertinax.services

import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.hardware.camera2.CameraManager
import android.os.IBinder
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class RealtimeService : Service() {

    private var isRunning = false
    private val logFile by lazy {
        File(filesDir, "realtime_log.txt")
    }

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        Log.i("RealtimeService", "Echtzeitüberwachung gestartet")
        startMonitoring()
    }

    private fun startMonitoring() {
        Thread {
            while (isRunning) {
                scanMicrophone()
                scanCameras()
                Thread.sleep(10000) // alle 10 Sekunden scannen
            }
        }.start()
    }

    private fun scanMicrophone() {
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val micStatus = if (audioManager.isMicrophoneMute) "stummgeschaltet" else "aktiv"
        log("Mikrofon ist $micStatus")
    }

    private fun scanCameras() {
        val cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val cameras = cameraManager.cameraIdList
        cameras.forEach { id ->
            log("Kamera erkannt: ID=$id")
        }
    }

    private fun log(entry: String) {
        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        logFile.appendText("[$timestamp] $entry\n")
        Log.i("RealtimeService", entry)
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        Log.i("RealtimeService", "Echtzeitüberwachung gestoppt")
    }

    override fun onBind(intent: Intent?): IBinder? = null
}