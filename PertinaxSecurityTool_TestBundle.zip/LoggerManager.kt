package com.pertinax.logging

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

object LoggerManager {

    /**
     * Schreibt einen Log-Eintrag in eine tägliche Logdatei.
     */
    fun log(context: Context, tag: String, message: String) {
        val logDir = File(context.filesDir, "logs")
        if (!logDir.exists()) {
            logDir.mkdirs()
        }
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val logFile = File(logDir, "log-\$date.txt")
        val timestamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val entry = "[\$timestamp] [\$tag] \$message\n"
        try {
            logFile.appendText(entry)
            Log.i(tag, message)
        } catch (e: Exception) {
            Log.e("LoggerManager", "Fehler beim Schreiben des Logs: \${e.message}")
        }
    }

    /**
     * Liest die Logdatei des aktuellen Tages und gibt sie als List<String> zurück.
     */
    fun readLogs(context: Context): List<String> {
        val logDir = File(context.filesDir, "logs")
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val logFile = File(logDir, "log-\$date.txt")
        return if (logFile.exists()) {
            logFile.readLines()
        } else {
            emptyList()
        }
    }
}