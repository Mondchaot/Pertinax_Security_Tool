package com.pertinax.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.pertinax.display.DisplaySetup
import com.pertinax.services.GeoSnifferService
import com.pertinax.services.MessengerService
import com.pertinax.services.RealtimeService
import com.pertinax.update.UpdateManager

class MainDashboardActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DashboardScreen()
        }
        // Starten von Hintergrunddiensten
        startService(Intent(this, MessengerService::class.java))
        startService(Intent(this, RealtimeService::class.java))
        startService(Intent(this, GeoSnifferService::class.java))
    }
}

@Composable
fun DashboardScreen() {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Pertinax Security Tool", style = MaterialTheme.typography.h5)
        Button(onClick = { /* Display Helligkeit setzen */ }) {
            Text("Display Setup")
        }
        Button(onClick = { UpdateManager.checkForUpdates(/* context placeholder */ ContextProvider.current, "1.0.0") }) {
            Text("Nach Updates suchen")
        }
        Button(onClick = { /* Logs anzeigen */ }) {
            Text("Logs anzeigen")
        }
        Button(onClick = { 
            ContextProvider.current?.let { context ->
                Intent(context, MessengerService::class.java).apply {
                    context.startService(this)
                }
            }
         }) {
            Text("Messenger starten")
        }
        Button(onClick = { /* GeoSniffer anhalten oder Status anzeigen */ }) {
            Text("GeoSniffer Status")
        }
        Button(onClick = { /* Lizenz prüfen */ }) {
            Text("Lizenzprüfer")
        }
    }
}

// Hilfsklasse, um Composable mit Context zu versorgen
object ContextProvider {
    var current: android.content.Context? = null
}