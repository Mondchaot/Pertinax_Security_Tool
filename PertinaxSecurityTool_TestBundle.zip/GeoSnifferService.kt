package com.pertinax.services

import android.Manifest
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.*
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class GeoSnifferService : Service() {

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var isRunning = false
    private val logFile by lazy { File(filesDir, "geo_sniffer_log.json") }

    override fun onCreate() {
        super.onCreate()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        isRunning = true
        Log.i("GeoSnifferService", "GeoSniffer gestartet")
        startLocationUpdates()
    }

    private fun startLocationUpdates() {
        val locationRequest = LocationRequest.create().apply {
            interval = 15000  // alle 15 Sekunden
            fastestInterval = 10000
            priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        }
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Log.w("GeoSnifferService", "Keine Standortberechtigung")
            stopSelf()
            return
        }
        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper())
    }

    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            if (!isRunning) return
            for (location in result.locations) {
                logLocation(location)
            }
        }
    }

    private fun logLocation(location: Location) {
        try {
            val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
            val entry = JSONObject().apply {
                put("timestamp", timestamp)
                put("latitude", location.latitude)
                put("longitude", location.longitude)
                put("accuracy", location.accuracy)
            }
            logFile.appendText(entry.toString() + "\n")
            Log.i("GeoSnifferService", "Ort protokolliert: \$entry")
        } catch (e: Exception) {
            Log.e("GeoSnifferService", "Fehler beim Protokollieren: \${e.message}")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        fusedLocationClient.removeLocationUpdates(locationCallback)
        isRunning = false
        Log.i("GeoSnifferService", "GeoSniffer gestoppt")
    }

    override fun onBind(intent: Intent?): IBinder? = null
}