package com.pertinax.display

import android.content.Context
import android.provider.Settings
import android.util.Log
import androidx.core.content.ContextCompat
import android.view.WindowManager
import android.view.Window
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.widget.Toast

object DisplaySetup {

    /**
     * Setzt die Bildschirmhelligkeit (0-255).
     */
    fun setBrightness(context: Context, brightness: Int) {
        try {
            if (Settings.System.canWrite(context)) {
                val clamped = brightness.coerceIn(0, 255)
                Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, clamped)
                Toast.makeText(context, "Helligkeit gesetzt: \$clamped", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "Bitte Schreibrechte für Systemeinstellungen erlauben", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Log.e("DisplaySetup", "Fehler beim Setzen der Helligkeit: \${e.message}")
        }
    }

    /**
     * Wendet einen Farbfilter (z.B. smaragdgrüner Farbton) auf das Fenster an.
     */
    fun applyColorFilter(window: Window) {
        try {
            val matrix = ColorMatrix()
            // Beispiel: Grünstich erhöhen
            matrix.set(
                floatArrayOf(
                    0f, 1f, 0f, 0f, 0f,
                    0f, 1f, 0f, 0f, 0f,
                    0f, 1f, 0f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            val filter = ColorMatrixColorFilter(matrix)
            window.decorView.overlay?.colorFilter = filter
        } catch (e: Exception) {
            Log.e("DisplaySetup", "Fehler beim Anwenden des Farbfilters: \${e.message}")
        }
    }

    /**
     * Aktiviert Zoom (vergrößert die Skalierung) auf das Fenster.
     */
    fun enableZoom(window: Window, scale: Float) {
        try {
            val layoutParams = window.attributes
            layoutParams.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
            window.attributes = layoutParams
            window.decorView.scaleX = scale
            window.decorView.scaleY = scale
        } catch (e: Exception) {
            Log.e("DisplaySetup", "Fehler beim Aktivieren des Zooms: \${e.message}")
        }
    }
}