package com.pertinax.update

import android.content.Context
import android.util.Log
import kotlinx.coroutines.*
import java.io.File
import java.net.URL

object UpdateManager {

    private const val UPDATE_URL = "https://example.com/pertinax/update/latest.apk"

    /**
     * Überprüft auf ein neues Update und lädt es herunter, falls verfügbar.
     */
    fun checkForUpdates(context: Context, currentVersion: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Beispiel: App-Version abfragen (hier symbolisch)
                val latestVersion = URL("https://example.com/pertinax/update/version.txt").readText().trim()
                if (latestVersion != currentVersion) {
                    withContext(Dispatchers.Main) {
                        Log.i("UpdateManager", "Neues Update verfügbar: \$latestVersion")
                    }
                    downloadUpdate(context)
                } else {
                    withContext(Dispatchers.Main) {
                        Log.i("UpdateManager", "App ist aktuell")
                    }
                }
            } catch (e: Exception) {
                Log.e("UpdateManager", "Fehler bei Update-Prüfung: \${e.message}")
            }
        }
    }

    private fun downloadUpdate(context: Context) {
        try {
            val apkFile = File(context.getExternalFilesDir(null), "PertinaxUpdate.apk")
            URL(UPDATE_URL).openStream().use { input ->
                apkFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }
            Log.i("UpdateManager", "Update heruntergeladen: \${apkFile.absolutePath}")
            // Optional: Installation triggern (Intent ACTION_VIEW)
        } catch (e: Exception) {
            Log.e("UpdateManager", "Fehler beim Herunterladen: \${e.message}")
        }
    }
}