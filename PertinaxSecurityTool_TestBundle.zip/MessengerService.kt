package com.pertinax.services

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log
import com.pertinax.security.messenger.MessengerEncryptor
import java.util.*

class MessengerService : Service() {

    private val retryQueue = LinkedList<String>()
    private var isRunning = false

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        Log.i("MessengerService", "Dienst gestartet")
        startRetryLoop()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Optionale direkte Nachricht (z. B. aus GUI)
        val msg = intent?.getStringExtra("message")
        msg?.let {
            sendMessage(it)
        }
        return START_STICKY
    }

    private fun startRetryLoop() {
        Thread {
            while (isRunning) {
                if (retryQueue.isNotEmpty()) {
                    val msg = retryQueue.poll()
                    try {
                        // Simulierte Wiederholung (z. B. Netzwerk send)
                        Log.i("MessengerService", "Sende erneut: $msg")
                        MessengerEncryptor.sendMessage(msg)
                    } catch (e: Exception) {
                        Log.e("MessengerService", "Retry fehlgeschlagen: ${e.message}")
                        retryQueue.add(msg)
                    }
                }
                Thread.sleep(5000)
            }
        }.start()
    }

    fun sendMessage(msg: String) {
        try {
            MessengerEncryptor.sendMessage(msg)
        } catch (e: Exception) {
            Log.e("MessengerService", "Sofortiger Sendeversuch fehlgeschlagen – wird erneut")
            retryQueue.add(msg)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        Log.i("MessengerService", "Dienst gestoppt")
    }

    override fun onBind(intent: Intent?): IBinder? = null
}