package com.pertinax.launcher

import android.content.Context
import android.content.Intent
import android.util.Log
import com.pertinax.security.MainDashboardActivity
import com.pertinax.services.MessengerService
import com.pertinax.services.RealtimeService

object StartManager {

    fun initialize(context: Context) {
        Log.i("StartManager", "Initialisierung gestartet...")

        // Starte GUI
        val intent = Intent(context, MainDashboardActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)

        // Starte Hintergrunddienste
        startService(context, MessengerService::class.java)
        startService(context, RealtimeService::class.java)

        Log.i("StartManager", "Startvorgang abgeschlossen")
    }

    private fun startService(context: Context, serviceClass: Class<*>) {
        val serviceIntent = Intent(context, serviceClass)
        context.startService(serviceIntent)
    }
}