package com.pertinax.gui

import android.content.Context
import android.util.Log
import android.widget.Toast
import kotlinx.coroutines.*
import java.security.MessageDigest

object LicenseVerifierUI {

    private val validHashes = listOf(
        "94ee059335e587e501cc4bf90613e0814f00a7b08bc7c648fd865a2af6a22cc2" // Beispiel: gültiger Lizenz-Hash
    )

    fun checkLicense(context: Context, licenseKey: String) {
        CoroutineScope(Dispatchers.IO).launch {
            val hash = sha256(licenseKey)
            withContext(Dispatchers.Main) {
                if (validHashes.contains(hash)) {
                    Toast.makeText(context, "✔️ Lizenz gültig: Premium-Modus aktiviert", Toast.LENGTH_LONG).show()
                    Log.i("LicenseVerifier", "Gültige Lizenz erkannt.")
                } else {
                    Toast.makeText(context, "❌ Lizenz ungültig oder abgelaufen", Toast.LENGTH_LONG).show()
                    Log.w("LicenseVerifier", "Ungültige Lizenz.")
                }
            }
        }
    }

    private fun sha256(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest(input.toByteArray())
        return hashBytes.joinToString("") { "%02x".format(it) }
    }
}