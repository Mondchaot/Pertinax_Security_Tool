import hashlib
from fastapi import HTTPException

VALID_LICENSE_HASHES = {
    # Beispielhafter Hash eines gültigen Lizenzschlüssels
    "94ee059335e587e501cc4bf90613e0814f00a7b08bc7c648fd865a2af6a22cc2": "Premium User"
}

def verify_license_key(license_key: str) -> str:
    hashed = hashlib.sha256(license_key.encode('utf-8')).hexdigest()
    if hashed in VALID_LICENSE_HASHES:
        return VALID_LICENSE_HASHES[hashed]
    raise HTTPException(status_code=401, detail="Lizenz ungültig oder abgelaufen")